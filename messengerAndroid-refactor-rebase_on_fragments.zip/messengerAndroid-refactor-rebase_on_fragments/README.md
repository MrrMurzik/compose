# Messenger for android

Idea, design and technical specification was given by SH++ school (https://programming.org.ua/)
The project divided in 5 levels (tasks), each task solves some group of problems. Each task in order of increasing number was developed with more complex technology.

Level 1
Technologies was used: XML basics, Activity, Intents
